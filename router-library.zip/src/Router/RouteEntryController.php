<?php

namespace Simp\Router\Router;

abstract class RouteEntryController implements EntryInterface {}